/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}"  // ✅ 반드시 이렇게 포함되어야 함
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};
